package com.example.contactsfetchrecycler;

/**
 * Created by dazzledapps Aquib on 3/10/17.
 */

public class ContactsBean {

    String mDisplayName;
    String mNickName = "";
    String mHomePhone = "";
    String mMobilePhone = "";

    public ContactsBean(String mDisplayName, String mNickName, String mHomePhone, String mMobilePhone,
                        String mWorkPhone, String mPhotoPath, String mHomeEmail, String mWorkEmail,
                        String mCompanyName, String mTitle) {
        this.mDisplayName = mDisplayName;
        this.mNickName = mNickName;
        this.mHomePhone = mHomePhone;
        this.mMobilePhone = mMobilePhone;
        this.mWorkPhone = mWorkPhone;
        this.mPhotoPath = mPhotoPath;
        this.mHomeEmail = mHomeEmail;
        this.mWorkEmail = mWorkEmail;
        this.mCompanyName = mCompanyName;
        this.mTitle = mTitle;
    }

    String mWorkPhone = "";
    String mPhotoPath = "";
    String mHomeEmail = "";

    public String getmDisplayName() {
        return mDisplayName;
    }

    public void setmDisplayName(String mDisplayName) {
        this.mDisplayName = mDisplayName;
    }

    public String getmNickName() {
        return mNickName;
    }

    public void setmNickName(String mNickName) {
        this.mNickName = mNickName;
    }

    public String getmHomePhone() {
        return mHomePhone;
    }

    public void setmHomePhone(String mHomePhone) {
        this.mHomePhone = mHomePhone;
    }

    public String getmMobilePhone() {
        return mMobilePhone;
    }

    public void setmMobilePhone(String mMobilePhone) {
        this.mMobilePhone = mMobilePhone;
    }

    public String getmWorkPhone() {
        return mWorkPhone;
    }

    public void setmWorkPhone(String mWorkPhone) {
        this.mWorkPhone = mWorkPhone;
    }

    public String getmPhotoPath() {
        return mPhotoPath;
    }

    public void setmPhotoPath(String mPhotoPath) {
        this.mPhotoPath = mPhotoPath;
    }

    public String getmHomeEmail() {
        return mHomeEmail;
    }

    public void setmHomeEmail(String mHomeEmail) {
        this.mHomeEmail = mHomeEmail;
    }

    public String getmWorkEmail() {
        return mWorkEmail;
    }

    public void setmWorkEmail(String mWorkEmail) {
        this.mWorkEmail = mWorkEmail;
    }

    public String getmCompanyName() {
        return mCompanyName;
    }

    public void setmCompanyName(String mCompanyName) {
        this.mCompanyName = mCompanyName;
    }

    public String getmTitle() {
        return mTitle;
    }

    public void setmTitle(String mTitle) {
        this.mTitle = mTitle;
    }

    String mWorkEmail = "";
    String mCompanyName = "";
    String mTitle = "";
}
